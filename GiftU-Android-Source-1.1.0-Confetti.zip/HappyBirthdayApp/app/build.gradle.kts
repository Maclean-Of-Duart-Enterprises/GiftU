plugins {
    id("com.android.application")
}

android {
    namespace = "com.macleanofduartenterprises.giftu"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.macleanofduartenterprises.giftu"
        minSdk = 23
        targetSdk = 35
        versionCode = 2
        versionName = "1.1.0"
    }
}
