package com.macleanofduartenterprises.giftu;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * Lightweight, dependency-free confetti animation used as the app background.
 * Confetti pops automatically and wherever the user taps the background.
 */
public final class ConfettiView extends View {
    private static final int MAX_PARTICLES = 180;
    private static final float GRAVITY = 610f;

    private static final int[] CONFETTI_COLORS = {
            Color.rgb(255, 77, 109),
            Color.rgb(255, 183, 3),
            Color.rgb(0, 187, 249),
            Color.rgb(131, 56, 236),
            Color.rgb(6, 214, 160),
            Color.rgb(255, 112, 67),
            Color.rgb(247, 37, 133)
    };

    private final Paint backgroundPaint = new Paint();
    private final Paint confettiPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint burstPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final List<Particle> particles = new ArrayList<>();
    private final List<Burst> bursts = new ArrayList<>();
    private final Random random = new Random();

    private long lastFrameTime;
    private long lastAutomaticBurst;
    private long nextBurstDelay = 1050L;
    private boolean running;

    public ConfettiView(Context context) {
        super(context);
        setClickable(true);
        setFocusable(false);
        burstPaint.setStyle(Paint.Style.STROKE);
        burstPaint.setStrokeWidth(dp(2));
    }

    @Override
    protected void onSizeChanged(int width, int height, int oldWidth, int oldHeight) {
        super.onSizeChanged(width, height, oldWidth, oldHeight);
        backgroundPaint.setShader(new LinearGradient(
                0f,
                0f,
                0f,
                height,
                new int[]{0xFFFFF8EE, 0xFFF0F8FF, 0xFFFFF1F7},
                new float[]{0f, 0.52f, 1f},
                Shader.TileMode.CLAMP));

        particles.clear();
        bursts.clear();
        if (width > 0 && height > 0) {
            spawnBurst(width * 0.5f, height * 0.28f, 30);
            lastAutomaticBurst = SystemClock.uptimeMillis();
        }
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        running = true;
        lastFrameTime = SystemClock.uptimeMillis();
        postInvalidateOnAnimation();
    }

    @Override
    protected void onDetachedFromWindow() {
        running = false;
        super.onDetachedFromWindow();
    }

    @Override
    protected void onWindowVisibilityChanged(int visibility) {
        super.onWindowVisibilityChanged(visibility);
        running = visibility == VISIBLE;
        if (running) {
            lastFrameTime = SystemClock.uptimeMillis();
            postInvalidateOnAnimation();
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawRect(0f, 0f, getWidth(), getHeight(), backgroundPaint);

        long now = SystemClock.uptimeMillis();
        float elapsedSeconds = Math.min(0.034f, Math.max(0f, (now - lastFrameTime) / 1000f));
        lastFrameTime = now;

        if (running && getWidth() > 0 && getHeight() > 0
                && now - lastAutomaticBurst >= nextBurstDelay) {
            float x = getWidth() * (0.16f + random.nextFloat() * 0.68f);
            float y = getHeight() * (0.13f + random.nextFloat() * 0.30f);
            spawnBurst(x, y, 22 + random.nextInt(9));
            lastAutomaticBurst = now;
            nextBurstDelay = 900L + random.nextInt(700);
        }

        updateAndDrawBursts(canvas, elapsedSeconds);
        updateAndDrawParticles(canvas, elapsedSeconds);

        if (running) {
            postInvalidateOnAnimation();
        }
    }

    private void updateAndDrawBursts(Canvas canvas, float elapsedSeconds) {
        Iterator<Burst> iterator = bursts.iterator();
        while (iterator.hasNext()) {
            Burst burst = iterator.next();
            burst.age += elapsedSeconds;
            float progress = burst.age / burst.life;
            if (progress >= 1f) {
                iterator.remove();
                continue;
            }

            burstPaint.setColor(burst.color);
            burstPaint.setAlpha(Math.round(150f * (1f - progress)));
            burstPaint.setStrokeWidth(dp(2) * (1f - progress * 0.45f));
            canvas.drawCircle(burst.x, burst.y, dp(8) + dp(32) * progress, burstPaint);
        }
    }

    private void updateAndDrawParticles(Canvas canvas, float elapsedSeconds) {
        Iterator<Particle> iterator = particles.iterator();
        while (iterator.hasNext()) {
            Particle particle = iterator.next();
            particle.age += elapsedSeconds;
            particle.velocityY += GRAVITY * elapsedSeconds;
            particle.x += (particle.velocityX
                    + (float) Math.sin(particle.age * particle.swaySpeed + particle.phase)
                    * particle.swayAmount) * elapsedSeconds;
            particle.y += particle.velocityY * elapsedSeconds;
            particle.rotation += particle.rotationSpeed * elapsedSeconds;

            if (particle.age >= particle.life
                    || particle.y > getHeight() + dp(48)
                    || particle.x < -dp(70)
                    || particle.x > getWidth() + dp(70)) {
                iterator.remove();
                continue;
            }

            float remaining = particle.life - particle.age;
            float opacity = Math.min(1f, remaining / 0.55f);
            float flip = 0.30f + 0.70f * Math.abs((float) Math.cos(
                    particle.age * particle.flipSpeed + particle.phase));
            confettiPaint.setColor(particle.color);
            confettiPaint.setAlpha(Math.round(235f * opacity));
            confettiPaint.setStyle(Paint.Style.FILL);

            canvas.save();
            canvas.translate(particle.x, particle.y);
            canvas.rotate(particle.rotation);
            canvas.scale(flip, 1f);
            if (particle.shape == 0) {
                float radius = Math.min(particle.width, particle.height) * 0.28f;
                canvas.drawRoundRect(
                        -particle.width / 2f,
                        -particle.height / 2f,
                        particle.width / 2f,
                        particle.height / 2f,
                        radius,
                        radius,
                        confettiPaint);
            } else if (particle.shape == 1) {
                canvas.drawCircle(0f, 0f, particle.width * 0.48f, confettiPaint);
            } else {
                canvas.drawRect(
                        -particle.width / 2f,
                        -particle.height / 2f,
                        particle.width / 2f,
                        particle.height / 2f,
                        confettiPaint);
            }
            canvas.restore();
        }
    }

    private void spawnBurst(float x, float y, int requestedCount) {
        int available = Math.max(0, MAX_PARTICLES - particles.size());
        int count = Math.min(requestedCount, available);
        int ringColor = CONFETTI_COLORS[random.nextInt(CONFETTI_COLORS.length)];
        bursts.add(new Burst(x, y, ringColor));

        for (int index = 0; index < count; index++) {
            float angle = (float) (-Math.PI + random.nextFloat() * Math.PI * 2f);
            float speed = dp(115) + random.nextFloat() * dp(185);
            Particle particle = new Particle();
            particle.x = x;
            particle.y = y;
            particle.velocityX = (float) Math.cos(angle) * speed;
            particle.velocityY = (float) Math.sin(angle) * speed - dp(75);
            particle.width = dp(5) + random.nextFloat() * dp(5);
            particle.height = dp(8) + random.nextFloat() * dp(8);
            particle.rotation = random.nextFloat() * 360f;
            particle.rotationSpeed = -260f + random.nextFloat() * 520f;
            particle.swaySpeed = 3.5f + random.nextFloat() * 3.5f;
            particle.swayAmount = dp(8) + random.nextFloat() * dp(15);
            particle.flipSpeed = 5f + random.nextFloat() * 7f;
            particle.phase = random.nextFloat() * (float) Math.PI * 2f;
            particle.life = 2.2f + random.nextFloat() * 1.35f;
            particle.color = CONFETTI_COLORS[random.nextInt(CONFETTI_COLORS.length)];
            particle.shape = random.nextInt(3);
            particles.add(particle);
        }
        if (running) {
            postInvalidateOnAnimation();
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getActionMasked() == MotionEvent.ACTION_DOWN) {
            spawnBurst(event.getX(), event.getY(), 30);
            return true;
        }
        if (event.getActionMasked() == MotionEvent.ACTION_UP) {
            performClick();
            return true;
        }
        return super.onTouchEvent(event);
    }

    @Override
    public boolean performClick() {
        super.performClick();
        return true;
    }

    private float dp(float value) {
        return value * getResources().getDisplayMetrics().density;
    }

    private static final class Particle {
        float x;
        float y;
        float velocityX;
        float velocityY;
        float width;
        float height;
        float rotation;
        float rotationSpeed;
        float swaySpeed;
        float swayAmount;
        float flipSpeed;
        float phase;
        float age;
        float life;
        int color;
        int shape;
    }

    private static final class Burst {
        final float x;
        final float y;
        final int color;
        final float life = 0.42f;
        float age;

        Burst(float x, float y, int color) {
            this.x = x;
            this.y = y;
            this.color = color;
        }
    }
}
