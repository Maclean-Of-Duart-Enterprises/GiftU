package com.macleanofduartenterprises.giftu;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FrameLayout page = new FrameLayout(this);
        page.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        ConfettiView confetti = new ConfettiView(this);
        confetti.setImportantForAccessibility(android.view.View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        page.addView(confetti, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        TextView message = new TextView(this);
        message.setText("Happy Birthday to You");
        message.setTextSize(TypedValue.COMPLEX_UNIT_SP, 34f);
        message.setTextColor(Color.rgb(27, 37, 64));
        message.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        message.setGravity(Gravity.CENTER);
        message.setLetterSpacing(0.015f);
        message.setMaxLines(2);
        message.setPadding(dp(28), dp(22), dp(28), dp(22));
        message.setShadowLayer(dp(1), 0f, dp(1), 0x22000000);
        message.setElevation(dp(8));

        GradientDrawable card = new GradientDrawable();
        card.setColor(0xEFFFFFFF);
        card.setCornerRadius(dp(28));
        card.setStroke(dp(1), 0x99FFFFFF);
        message.setBackground(card);

        FrameLayout.LayoutParams messageLayout = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER);
        messageLayout.setMargins(dp(24), dp(24), dp(24), dp(24));
        page.addView(message, messageLayout);

        setContentView(page);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
