GiftU Android App
=================

App name: GiftU
Application ID: com.macleanofduartenterprises.giftu
Version: 1.1.0

Behavior:
- Fully local/offline Android application.
- No Internet permission, accounts, ads, analytics, or cloud services.
- Opens to a page displaying: Happy Birthday to You
- Displays a smooth, colorful confetti-popping animated background.
- Pops additional confetti wherever the background is tapped.
- Uses a bounded particle count and pauses animation when the app is not visible.
- Uses the balloon-and-confetti VectorDrawable launcher icon.
